<?php

session_start();
   unset($_SESSION['name']);
   session_destroy();			// DESTROYS SESSION AND TAKES US TO LOGIN PAGE
   header('location:login.php')
?>