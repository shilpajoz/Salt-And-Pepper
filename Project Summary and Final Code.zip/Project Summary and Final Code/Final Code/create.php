

<?php 
require("conn.php");
if (isset($_POST['upload'])) {
    // Get image name
     $a=$_POST['password'];                 //Create new account
     $b=$_POST['inputPassword'];
     $c=$_POST['inputEmail'];
     $d=$_POST['p_name'];
     if ($a==$b) {
        $sql = "INSERT INTO user_log (uname, uemail, u_pass)    
        VALUES ('$d', '$c', '$a')";                            //Insert username , mailid, password into database
        if ($conn->query($sql) === TRUE) {
   // echo "New record created successfully";
            header('Location: login.html');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>RECEIPE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/Comment.css">
    <link rel="stylesheet" href="assets/css/Community-ChatComments.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Text-Input.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body style="background-image: url(&quot;assets/img/y1ostvqnr4711.jpg&quot;);">
    <div class="row no-gutters" style="padding: -11px;background-image: url(&quot;none&quot;);">
        <div class="col">
            <div class="login-card" style="height: 409px;"><img class="profile-img-card" src="assets/img/avatar_2x.png">
                <p class="profile-name-card"> </p>
                <form class="form-signin" method="POST"><span class="reauth-email"> </span><input class="form-control" type="text" name="p_name" required="" placeholder="Name address" autofocus=""><input class="form-control" type="email" name="inputEmail" required="" placeholder="Email address" autofocus=""><input class="form-control" type="password" name="password" required="" placeholder="Password">
                    <input
                        class="form-control" type="password" name="inputPassword" required="" placeholder="Password">
                        <div class="checkbox"></div><button class="btn btn-primary btn-block btn-lg btn-signin" type="submit" name="upload" style="width: 233px;">Create Account</button></form>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>

