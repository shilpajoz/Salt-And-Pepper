<?php
require("conn.php");

$email=$_POST['email'];
$pass=$_POST['pass'];
	
session_start();

$sql = "SELECT * FROM user_log WHERE uemail='$email' AND u_pass='$pass' ";			//USER VALIDATION IS DONE 
$result = $conn->query($sql);


if($result->num_rows > 0) {
	$_SESSION["name"] = $email;
	echo $_SESSION["name"];
    
    header('Location: index.php');
    
    
} else {	 header('Location: create.php');?><script>
  alert("Create a new account");
 
    
</script>
<?php
}
?>