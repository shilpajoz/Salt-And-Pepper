<?php
// Add recipe to diet plan
session_start();
require "conn.php";
$uemail= $_SESSION["name"];

if($uemail==""){
	header('Location: login.php');
}else{
	$sql = "SELECT * FROM user_log where uemail='$uemail' ";
	$result = $conn->query($sql);
	while($rowe = $result->fetch_assoc()) {
		$uname= $rowe['uemail'];
		$r_id=  $_POST['id'];
		$sql = "SELECT * FROM favi where recipe_id='$r_id' and user_id='$uname' ";
		$result = $conn->query($sql);
		if($row = $result->fetch_assoc()) {
			echo "Alredy Its In Diet plan";
		} else {
			$sql = "SELECT * FROM recipe where id='$r_id'  ";
			$result = $conn->query($sql);
			if($row = $result->fetch_assoc()) {
				$c=$row['short_text'];
 				$d=$row['long_text'];
 				$b=$row['news_head'];
 				$a=$row['img'];
 				$e=$row['id'];
 				$sql = "INSERT INTO favi (recipe_id, user_id,a,b,c,d,e) 
 				VALUES ('$r_id','$uname','$a','$b','$c','$d','$e')"; // inserts the recipe to diet plan
 				$conn->query($sql);
 				echo "Added To Diet Plan";
 			}
 		}
 	}
 }
?>