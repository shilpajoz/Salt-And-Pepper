
<?php 
session_start();
require "conn.php";
$uemail= $_SESSION["name"];
if($uemail==""){
 header('Location: login.php');
} else {
    $sql = "SELECT * FROM user_log where uemail='$uemail' ";
    $result = $conn->query($sql);
    while($row = $result->fetch_assoc()) {
        $db = mysqli_connect("localhost", "root", "", "user_log");
        $msg="";
   // If upload button is clicked ...
        if (isset($_POST['upload'])) {
    // Get image name
            $image = $_FILES['image']['name'];
    // Get text
            $short_text = mysqli_real_escape_string($db, $_POST['short_text']);
            $long_text=mysqli_real_escape_string($db, $_POST['long_text']);
            $country= mysqli_real_escape_string($db, $_POST['count']);
            $head= mysqli_real_escape_string($db, $_POST['head']);

    // image file directory
            $target = "img/".basename($image);
            $t="img/".basename($image);
            $sql = "INSERT INTO recipe (country,news_head, img,short_text,long_text) VALUES ('$country','$head', '$t','$short_text','$long_text')";
    // execute query
            mysqli_query($db, $sql);
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                $msg = "Image uploaded successfully";
            } else {
                $msg = "Failed to upload image";
            }
        }
        ?>
<!DOCTYPE php>
<php>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>RECEIPE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/Comment.css">
    <link rel="stylesheet" href="assets/css/Community-ChatComments.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Text-Input.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <!-- Include Editor style. -->
    <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>


</head>

<body>
    <div class="row no-gutters top" style="filter: blur(0px) brightness(111%) contrast(52%) grayscale(30%) hue-rotate(40deg) invert(10%);">
        <div class="col-5 col-sm-3 col-md-3 col-lg-2 col-xl-2 offset-xl-0 head-bottom"><h3><a  class="text-monospace" href="index.php">Recipie</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-3 col-xl-3 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="index.php">Favourite</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 offset-md-0 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="edit.php">EditProfile</a></h3></div>
        <div class="col-7 col-sm-3 col-md-2 col-lg-2 col-xl-2 offset-6 offset-sm-10 offset-md-1 offset-lg-1 offset-xl-1"><h3><a  class="text-monospace" style="color:blue;" href="logout.php">Logout</a></h3></div>
    </div>
    <div class="row no-gutters">
        <div class="col-7 col-sm-5 col-md-4 col-lg-3 col-xl-3 offset-sm-1 offset-md-1 offset-lg-1 offset-xl-1">
            <ol class="breadcrumb rad" style="width: 190px;">
                <li class="breadcrumb-item"><a href="#"><span><i class="fa fa-home"></i>&nbsp;<a class="text-uppercase" href="index.php">Home</a></span>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#"><a class="text-uppercase" >add recipie</a><span></span></a>
                </li>
            </ol>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-2 col-xl-2 offset-md-4 offset-lg-6 offset-xl-5"><a class="btn btn-primary pull-right"href="index.php"><i class="fa fa-arrow-left"></i>&nbsp;Back</a></div>
    </div> <form method="POST" enctype="multipart/form-data" >
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-1 offset-md-2 offset-lg-5 offset-xl-5"><img style="width: 237px;height: 235px;" src="assets/img/avatar_2x.png"></div>
    </div>
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-1 offset-md-2 offset-lg-5 offset-xl-5"><input type="file" name="image"></div>
    </div>
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-1 offset-md-2 offset-lg-5 offset-xl-6" style="padding: 31px;">
            <div class="dropdown">
                <select class="btn btn-primary dropdown-toggle" name="count">
   <?php
          $sql = "SELECT * FROM countries  ";
$result = $conn->query($sql);

  while($row = $result->fetch_assoc()) {
           ?>
  <option value="<?php echo $row['country'];?>"><?php echo $row['country'];?></option>
<?php }?>
</select>

               
            </div>
        </div>
    </div>
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-3 offset-md-2 offset-lg-5 offset-xl-5"><input type="text" name="head" placeholder="Add Heading"></div>
    </div>
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-7 offset-md-0 offset-lg-2 offset-xl-4" style="width: 528px;padding: 32px;"><textarea name="short_text" id="short_text" placeholder="short text" style="width: 670px;height: 221px;"> Short Summery</textarea></div>
    </div>    
    <div class="row no-gutters">
        <div class="col-md-9 col-lg-3 col-xl-7 offset-md-0 offset-lg-2 offset-xl-4" style="width: 528px;padding: 32px;"><textarea name="long_text" placeholder="long text" id="long_text" style="width: 670px;height: 221px;">Long Summery</textarea></div>
    </div>
     <div class="col-sm-6 col-md-3 col-lg-2 col-xl-2 offset-md-4 offset-lg-6 offset-xl-5"><button class="btn btn-primary pull-right"name="upload"><i class="fa fa-arrow-left"></i>&nbsp;submit</button></div></form>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
   
        <script>
    
    CKEDITOR.replace( 'long_text' );
    CKEDITOR.replace( 'short_text' );

    </script>
</body>

</php>
<?php 
}}?>
