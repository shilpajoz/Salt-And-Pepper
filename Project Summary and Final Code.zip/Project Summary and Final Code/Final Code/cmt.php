<?php
session_start();
require "conn.php";
$uemail= $_SESSION["name"];
if($uemail==""){
	header('Location: login.php');
} else {
	$id=  $_POST['id'];						// FETCH THE USERNAME
	$sql = "SELECT * FROM cmt where recipe_id='$id' ";				
	$result = $conn->query($sql);
	if($row = $result->fetch_assoc()) {
		while($rowe = $result->fetch_assoc()) {			// PRINT THE COMMENT
			?>
			<p><a href="#"><?php echo $rowe['user_id'];?> : </a> <?php echo $rowe['msg'];?> <br></p>
		<?php } }else{ ?> 
			<p><H1>Be First To Comment !!</H1> <br></p>   
																				//If no one has commented before
			<?php
		} 
	}
	?>