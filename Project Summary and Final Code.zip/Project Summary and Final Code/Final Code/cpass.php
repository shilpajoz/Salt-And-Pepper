<?php

session_start();
require "conn.php";
$uemail= $_SESSION["name"];

if($uemail==""){
	header('Location: login.php');
}else{
	$a=$_POST['n_pass'];
	$b=$_POST['c_pass'];			// update passwords, mailid etc..
	if ($a==$b) {
		$sql="UPDATE user_log SET u_pass='$a' WHERE uemail='$uemail'";	
		if ($conn->query($sql) === TRUE) {
			header("Location:edit.php");
		} else {
			echo "Error updating record: " . $conn->error;
		}
	}
?>