<?php
require("conn.php");

$email=$_POST['email'];
$pass=$_POST['pass'];
	
session_start();

$sql = "SELECT * FROM admin WHERE admin='$email' AND admin_pass='$pass' ";			//USER VALIDATION FOR ADMIN
$result = $conn->query($sql);


if($result->num_rows > 0) {
	$_SESSION["name"] = $email;
	echo $_SESSION["name"];
    
    header('Location: recii.php');
    
    
} else {	 header('Location: admin_login.php');?><script>
  alert("Create a new account");
</script>
<?php
}
?>