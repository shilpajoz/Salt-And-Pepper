<?php 
session_start();
require "conn.php";
$uemail= $_SESSION["name"];

if($uemail==""){
    header('Location: login.php');
}else{
    $sql = "SELECT * FROM user_log where uemail='$uemail' ";
    $result = $conn->query($sql);
    if($row = $result->fetch_assoc()) {
        ?>
<!DOCTYPE php>
<php>                                   <!-- Edit the password and change it --> 
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>RECEIPE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/Comment.css">
    <link rel="stylesheet" href="assets/css/Community-ChatComments.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Text-Input.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <div class="row no-gutters top" style="filter: blur(0px) brightness(111%) contrast(52%) grayscale(30%) hue-rotate(40deg) invert(10%);">
        <div class="col-5 col-sm-3 col-md-3 col-lg-2 col-xl-2 offset-xl-0 head-bottom"><h3><a  class="text-monospace" href="index.php">Recipie</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-3 col-xl-3 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="favourite.php">Favourite</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 offset-md-0 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="edit.php">EditProfile</a></h3></div>
        <div class="col-7 col-sm-3 col-md-2 col-lg-2 col-xl-2 offset-6 offset-sm-10 offset-md-1 offset-lg-1 offset-xl-1"><h3><a  class="text-monospace" style="color:blue;" href="logout.php">Logout</a></h3></div>
    </div>
    <div class="row no-gutters">
        <div class="col-xl-10 offset-xl-1">
            <div class="card">
                <div class="card-body"> <form method="POST" action="cpass.php">
                    <div class="col-lg-4 col-xl-4 offset-lg-5 offset-xl-4"><div class="group">      
    <input type="email"  value="<?php echo $row['uemail'];?>" required>
    <span class="highlight"></span>
    <span class="bar"></span>
    <label>Email</label>
</div>


<div class="group">      
    <input type="Password"  name="n_pass" required>
    <span class="highlight"></span>
    <span class="bar"></span>
    <label>New Password</label>
</div>


<div class="group">      
    <input type="Password" name="c_pass" required>
    <span class="highlight"></span>
    <span class="bar"></span>
    <label>Change Password</label>
</div>


</div>
                    <div class="col-lg-2 col-xl-2 offset-lg-6 offset-xl-5"><button class="btn btn-primary" type="submit">SAVE</button></div></form>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</php>
<?php 

}}
?>