<?php 
session_start();
require "conn.php";
$uemail= $_SESSION["name"];

if($uemail==""){
    header('Location: login.php');
}else{
    $sql = "SELECT * FROM user_log where uemail='$uemail' ";
    $result = $conn->query($sql);
    if($row = $result->fetch_assoc()) {
        $id= $_GET['id'];
        $sql = "SELECT * FROM recipe  where country='$id' ";        // choose whether brekfast, lunch etc..
        $result = $conn->query($sql);
?>

<!DOCTYPE php>
<php>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>RECEIPE</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Playfair+Display:400,700">
    <link rel="stylesheet" href="assets/css/cards.css">
    <link rel="stylesheet" href="assets/css/Comment.css">
    <link rel="stylesheet" href="assets/css/Community-ChatComments.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css">
    <link rel="stylesheet" href="assets/css/Google-Style-Text-Input.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider-1.css">
    <link rel="stylesheet" href="assets/css/MUSA_carousel-product-cart-slider.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body class="mr-auto">
    <div class="row no-gutters top" style="filter: blur(0px) brightness(111%) contrast(52%) grayscale(30%) hue-rotate(40deg) invert(10%);">
        <div class="col-5 col-sm-3 col-md-3 col-lg-2 col-xl-2 offset-xl-0 head-bottom"><h3><a  class="text-monospace" href="index.php">Recipie</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-3 col-xl-3 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="index.php">Favourite</a></h3></div>
        <div class="col-6 col-sm-4 col-md-3 col-lg-2 col-xl-2 offset-md-0 offset-lg-1"><h3><a  class="text-monospace" style="color:blue;" href="edit.php">EditProfile</a></h3></div>
        <div class="col-7 col-sm-3 col-md-2 col-lg-2 col-xl-2 offset-6 offset-sm-10 offset-md-1 offset-lg-1 offset-xl-1"><h3><a  class="text-monospace" style="color:blue;" href="logout.php">Logout</a></h3></div>
    </div>
    <div class="row no-gutters">
        <div class="col-7 col-sm-5 col-md-4 col-lg-3 col-xl-3 offset-sm-1 offset-md-1 offset-lg-1 offset-xl-1">
            <ol class="breadcrumb rad" style="width: 210px;">
                <li class="breadcrumb-item"><a href="#"><span><i class="fa fa-home"></i>&nbsp;<a class="text-uppercase" href="index.php">Home</a></span>
                    </a>
                </li>
                <li class="breadcrumb-item"><a href="#"><a class="text-uppercase" href="index.php"><?php echo $id;?><span></span></a>
                </li>
            </ol>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-2 col-xl-2 offset-md-4 offset-lg-6 offset-xl-5"><a class="btn btn-primary pull-right"  href="addreci.php"><i class="fa fa-plus"></i>&nbsp;Add Recipies</a></div>
    </div>
    <div class="row no-gutters">
        <div class="col">
            <div class="container">
                <h2 class="text-uppercase" style="margin-top:52px;margin-left:34px;font-family:'Open Sans', sans-serif;font-size:22px;font-weight:800;line-height:32px;color:rgb(0,0,0);"><?php echo $id;?> RECIPIES</h2>
                <div class="cust_bloglistintro">
                    <p style="margin-left:34px;color:rgba(255,255,255,0.5);font-size:14px;"></p>
                </div>
                <div class="row">
                    <?php  while($rowe = $result->fetch_assoc()) { ?>
                <div
                    class="col-md-4 cust_blogteaser" style="padding-bottom:20px;margin-bottom:32px;"><a href="solo.php?id=<?php echo $rowe['id'];?>"><img class="img-fluid" style="height:auto;" src="<?php echo $rowe['img'];?>"></a>
                    <h3 style="text-align:left;margin-top:20px;font-family:'Open Sans', sans-serif;font-size:18px;margin-right:0;margin-left:24px;line-height:34px;letter-spacing:0px;font-style:normal;font-weight:bold;"><?php echo $rowe['news_head'];?><br></h3>
                    <p class="text-secondary" style="text-align:left;font-size:14px;font-family:'Open Sans', sans-serif;line-height:22px;color:rgb(9,9,10);margin-left:24px;"><?php echo $rowe['short_text'];?></p><a class="h4" href="solo.php?id=<?php echo $rowe['id'];?>"><i class="fa fa-arrow-circle-right" style="margin-left:23px;"></i></a></div>
                        <?php
    }?>

        </div>
    </div>
    </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</php>
<?php 

}}
?>
