<?php

session_start();
require "conn.php";
$uemail= $_SESSION["name"];

if($uemail==""){
	header('Location: login.php');
}else{

	$sql = "SELECT * FROM user_log where uemail='$uemail' ";
	$result = $conn->query($sql);
	while($rowe = $result->fetch_assoc()) {  //This code fetches user details and posts the comment
		$uname= $rowe['uname'];
		$r_id=  $_POST['id'];
		$c_cmt= $_POST['cmt'];
		$sql = "INSERT INTO cmt (recipe_id, user_id,msg)
		VALUES ('$r_id','$uname', '$c_cmt')";
		$conn->query($sql);

						}					
	}
?>